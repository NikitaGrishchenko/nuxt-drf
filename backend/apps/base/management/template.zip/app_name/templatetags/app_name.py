from django import template


# from .. import models

# register = template.Library()

# @register.inclusion_tag("path_to_template.html")
# def example(count: int) -> dict:
#     return {
#         "obj": models.Example.objects.all()[:count],
#     }
