from rest_framework import views

# from ..models import Example
# from .serializers import ExampleSerializer


# class ExampleListView(generics.ListCreateAPIView):
#     """  """

#     permission_classes = [IsAuthenticated]
#     serializer_class = ExampleSerializer
#     queryset = Example.objects.all()
